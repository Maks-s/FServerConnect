
--[[----------------------------------------------
	Général Config
-------------------------------------------------]]

// Model choisi!
FSCModel = "models/Eli.mdl"

// Nom de ton serveur !
FSC_ServerName = "TonServeur"

// Nom de deuxième ton serveur !
FSC_SecondServerName = "TonServeur"

// Adresse ip de ton serveur !
FSCServerIP = "192.168.1.67"

// Port de ton serveur !
FSCPort = "27017"

// Puissance du blur dans la frame !
FSCBlurPower = 50

// Dessiner le nom de l'addon au dessus du pnj, histoire de me remercier on va dire :p !
FSCDrawAddonName = true

// Message de bienvenue (laisser bienvenue son nom sera affiché après)
FSC_WelcomeMSG = "Bienvenue "

//
FSC_Suggestion = "Souhaites tu te connecter au serveur " -- laisser l'espace à la fin
