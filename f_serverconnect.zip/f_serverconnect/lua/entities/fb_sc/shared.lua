
ENT.Base = "base_ai" 
ENT.Type = "ai"
ENT.PrintName = "PNJ"
ENT.Category = "FServerConnect"
ENT.Author = "Fléodon"
ENT.Spawnable = true 
ENT.AdminSpawnable = true 